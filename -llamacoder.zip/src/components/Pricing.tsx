import { Check } from "lucide-react";
import { Button } from "./ui/button";

const plans = [
  {
    name: "الباقة الأساسية",
    price: "199",
    period: "/ شهرياً",
    description: "مناسب للشركات الصغيرة والمتاجر الناشئة",
    features: [
      "مستخدم واحد",
      "إدارة المخزون",
      "الفواتير والمبيعات",
      "تقارير أساسية",
      "دعم فني عبر البريد",
    ],
    popular: false,
    color: "slate",
  },
  {
    name: "الباقة الاحترافية",
    price: "399",
    period: "/ شهرياً",
    description: "مناسب للشركات المتوسطة والمتاجر المتقدمة",
    features: [
      "5 مستخدمين",
      "إدارة المخزون المتقدمة",
      "الفواتير والمبيعات",
      "إدارة المشتريات",
      "تقارير متقدمة",
      "دعم فني على مدار الساعة",
      "تحديثات مجانية",
    ],
    popular: true,
    color: "emerald",
  },
  {
    name: "الباقة المؤسسية",
    price: "799",
    period: "/ شهرياً",
    description: "مناسب للشركات الكبرى والمؤسسات",
    features: [
      "مستخدمين غير محدود",
      "جميع مميزات الاحترافية",
      "متعدد الفروع",
      "API للربط",
      "تقارير مخصصة",
      "مدقق حسابات",
      "دعم فني مخصص",
      "تدريب مجاني",
    ],
    popular: false,
    color: "purple",
  },
];

export function Pricing() {
  return (
    <section id="pricing" className="py-24 bg-white">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <span className="inline-block bg-emerald-100 text-emerald-600 px-4 py-2 rounded-full text-sm font-medium mb-4">
            باقاتنا
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-slate-800 mb-4">
            اختر الباقة المناسبة لعملك
          </h2>
          <p className="text-slate-600 max-w-2xl mx-auto">
            نوفر لك باقات متنوعة تناسب جميع أحجام الأعمال مع مرونة في الترقية أو الإلغاء
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <div
              key={index}
              className={`relative rounded-3xl p-8 transition-all duration-300 hover:-translate-y-2 ${
                plan.popular
                  ? "bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-2xl shadow-emerald-500/30 scale-105"
                  : "bg-white border-2 border-slate-100 hover:border-emerald-200 hover:shadow-xl"
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-amber-400 text-amber-900 px-4 py-1 rounded-full text-sm font-bold">
                  الأكثر طلباً
                </div>
              )}

              <div className="mb-6">
                <h3
                  className={`text-xl font-bold mb-2 ${
                    plan.popular ? "text-white" : "text-slate-800"
                  }`}
                >
                  {plan.name}
                </h3>
                <p
                  className={`text-sm ${
                    plan.popular ? "text-emerald-100" : "text-slate-500"
                  }`}
                >
                  {plan.description}
                </p>
              </div>

              <div className="mb-6">
                <span
                  className={`text-4xl font-bold ${
                    plan.popular ? "text-white" : "text-slate-800"
                  }`}
                >
                  {plan.price}
                </span>
                <span
                  className={`text-sm ${
                    plan.popular ? "text-emerald-100" : "text-slate-500"
                  }`}
                >
                  ريال{plan.period}
                </span>
              </div>

              <ul className="space-y-4 mb-8">
                {plan.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center gap-3">
                    <div
                      className={`w-5 h-5 rounded-full flex items-center justify-center ${
                        plan.popular ? "bg-white/20" : "bg-emerald-100"
                      }`}
                    >
                      <Check
                        className={`w-3 h-3 ${
                          plan.popular ? "text-white" : "text-emerald-600"
                        }`}
                      />
                    </div>
                    <span
                      className={`text-sm ${
                        plan.popular ? "text-white" : "text-slate-600"
                      }`}
                    >
                      {feature}
                    </span>
                  </li>
                ))}
              </ul>

              <Button
                className={`w-full py-6 rounded-xl font-bold transition-all ${
                  plan.popular
                    ? "bg-white text-emerald-600 hover:bg-emerald-50"
                    : "bg-slate-800 text-white hover:bg-slate-900"
                }`}
              >
                ابدأ الآن
              </Button>
            </div>
          ))}
        </div>

        {/* Bottom Note */}
        <div className="text-center mt-12">
          <p className="text-slate-500">
            جميع الباقات تشمل ضريبة القيمة المضافة • إمكانية الترقية أو الإلغاء في أي وقت
          </p>
        </div>
      </div>
    </section>
  );
}