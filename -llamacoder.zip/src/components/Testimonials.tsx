import { Star } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";

const testimonials = [
  {
    name: "أحمد محمد",
    role: "مدير شركة تجارية",
    content: "نظام رائع وسهل الاستخدام، ساعدني في تنظيم حساباتي وتوفير الكثير من الوقت والجهد. الدعم الفني ممتاز ومتجاوب.",
    rating: 5,
    initials: "أ م",
  },
  {
    name: "سارة العلي",
    role: "صاحبة متجر إلكتروني",
    content: "أفضل نظام محاسبي استخدمته! التقارير التفصيلية ساعدتني على فهم أداء متجري بشكل أفضل. أنصح به بشدة.",
    rating: 5,
    initials: "س ع",
  },
  {
    name: "خالد الحربي",
    role: "مدير مطعم",
    content: "الباقة الاحترافية مثالية لمطعمنا. إدارة المخزون والفواتير أصبحت أسهل بكثير. شكراً مالتي سيستم!",
    rating: 5,
    initials: "خ ح",
  },
  {
    name: "نورة القحطاني",
    role: "مديرة عيادة",
    content: "نظام متكامل يلبي جميع احتياجاتنا. الدعم الفني متاح دائماً ويحل أي مشكلة بسرعة. تجربة ممتازة!",
    rating: 5,
    initials: "ن ق",
  },
];

export function Testimonials() {
  return (
    <section id="testimonials" className="py-24 bg-slate-50">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <span className="inline-block bg-emerald-100 text-emerald-600 px-4 py-2 rounded-full text-sm font-medium mb-4">
            آراء العملاء
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-slate-800 mb-4">
            ماذا يقول عملاؤنا؟
          </h2>
          <p className="text-slate-600 max-w-2xl mx-auto">
            نفتخر بثقة عملائنا ونسعى دائماً لتقديم أفضل تجربة ممكنة
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl p-6 shadow-sm hover:shadow-lg transition-all duration-300 border border-slate-100"
            >
              {/* Stars */}
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                ))}
              </div>

              {/* Content */}
              <p className="text-slate-600 text-sm leading-relaxed mb-6">
                "{testimonial.content}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-3">
                <Avatar className="w-12 h-12">
                  <AvatarFallback className="bg-emerald-100 text-emerald-600 font-bold">
                    {testimonial.initials}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-bold text-slate-800">{testimonial.name}</div>
                  <div className="text-slate-500 text-sm">{testimonial.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}