import { Shield, Clock, Users, Settings, BarChart3, Zap } from "lucide-react";

const features = [
  {
    icon: Shield,
    title: "أمان عالي",
    description: "حماية بياناتك بأحدث تقنيات التشفير والنسخ الاحتياطي التلقائي",
    color: "emerald",
  },
  {
    icon: Clock,
    title: "تحديث مستمر",
    description: "تحديثات دورية ومجانية لإضافة مميزات جديدة وتحسين الأداء",
    color: "blue",
  },
  {
    icon: Users,
    title: "متعدد المستخدمين",
    description: "صلاحيات مخصصة لكل مستخدم مع إمكانية العمل المتزامن",
    color: "purple",
  },
  {
    icon: Settings,
    title: "تخصيص كامل",
    description: "إعدادات مرنة تتوافق مع طبيعة عملك ومتطلباتك",
    color: "orange",
  },
  {
    icon: BarChart3,
    title: "تقارير ذكية",
    description: "تقارير وإحصائيات تفصيلية لمتابعة أداء عملك بسهولة",
    color: "teal",
  },
  {
    icon: Zap,
    title: "سرعة عالية",
    description: "أداء سريع وفعال حتى مع كميات كبيرة من البيانات",
    color: "pink",
  },
];

export function Features() {
  return (
    <section id="features" className="py-24 bg-slate-50">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <span className="inline-block bg-emerald-100 text-emerald-600 px-4 py-2 rounded-full text-sm font-medium mb-4">
            مميزاتنا
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-slate-800 mb-4">
            لماذا تختار مالتي سيستم؟
          </h2>
          <p className="text-slate-600 max-w-2xl mx-auto">
            نقدم لك نظام محاسبي متكامل يجمع بين القوة والمرونة لتحقيق أفضل النتائج
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="group bg-white rounded-2xl p-8 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-2 border border-slate-100"
            >
              <div
                className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-6 transition-transform group-hover:scale-110 ${
                  feature.color === "emerald"
                    ? "bg-emerald-100"
                    : feature.color === "blue"
                    ? "bg-blue-100"
                    : feature.color === "purple"
                    ? "bg-purple-100"
                    : feature.color === "orange"
                    ? "bg-orange-100"
                    : feature.color === "teal"
                    ? "bg-teal-100"
                    : "bg-pink-100"
                }`}
              >
                <feature.icon
                  className={`w-7 h-7 ${
                    feature.color === "emerald"
                      ? "text-emerald-600"
                      : feature.color === "blue"
                      ? "text-blue-600"
                      : feature.color === "purple"
                      ? "text-purple-600"
                      : feature.color === "orange"
                      ? "text-orange-600"
                      : feature.color === "teal"
                      ? "text-teal-600"
                      : "text-pink-600"
                  }`}
                />
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-3">{feature.title}</h3>
              <p className="text-slate-600 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}