import { Button } from "./ui/button";
import { Play, Shield, Users, Clock } from "lucide-react";

export function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-900">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-20 right-20 w-96 h-96 bg-emerald-500 rounded-full blur-3xl"></div>
          <div className="absolute bottom-20 left-20 w-96 h-96 bg-teal-500 rounded-full blur-3xl"></div>
        </div>
      </div>

      <div className="container mx-auto px-4 relative z-10 pt-24">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="text-center lg:text-right">
            <div className="inline-flex items-center gap-2 bg-emerald-500/20 border border-emerald-500/30 rounded-full px-4 py-2 mb-6">
              <span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></span>
              <span className="text-emerald-300 text-sm font-medium">الإصدار الجديد متاح الآن</span>
            </div>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
              نظام محاسبي متكامل
              <span className="block text-emerald-400">لإدارة أعمالك بسهولة</span>
            </h1>

            <p className="text-lg text-slate-300 mb-8 max-w-xl mx-auto lg:mx-0">
              مالتي سيستم يوفر لك حلولاً برمجية متكاملة لإدارة حساباتك ومبيعاتك ومشترياتك بكفاءة عالية وأمان تام
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button className="bg-emerald-500 hover:bg-emerald-600 text-white px-8 py-6 text-lg rounded-full shadow-xl shadow-emerald-500/30 transition-all hover:shadow-emerald-500/50 hover:scale-105">
                ابدأ تجربة مجانية
              </Button>
              <Button variant="outline" className="border-white/30 text-white hover:bg-white/10 px-8 py-6 text-lg rounded-full flex items-center gap-2 justify-center">
                <Play className="w-5 h-5" />
                شاهد الفيديو
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 mt-12 pt-8 border-t border-white/10">
              <div className="text-center">
                <div className="text-3xl font-bold text-white">+500</div>
                <div className="text-slate-400 text-sm">عميل سعيد</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-white">99%</div>
                <div className="text-slate-400 text-sm">نسبة الرضا</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-white">24/7</div>
                <div className="text-slate-400 text-sm">دعم فني</div>
              </div>
            </div>
          </div>

          {/* Image/Illustration */}
          <div className="relative hidden lg:block">
            <div className="relative">
              {/* Main Dashboard Card */}
              <div className="bg-white/10 backdrop-blur-xl rounded-3xl p-6 border border-white/20 shadow-2xl">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                </div>
                <div className="space-y-4">
                  <div className="h-8 bg-gradient-to-r from-emerald-500/30 to-teal-500/30 rounded-lg"></div>
                  <div className="grid grid-cols-3 gap-3">
                    <div className="h-24 bg-emerald-500/20 rounded-xl p-3">
                      <div className="text-emerald-400 text-xs mb-2">المبيعات</div>
                      <div className="text-white font-bold text-lg">125,430</div>
                      <div className="text-emerald-400 text-xs">+12%</div>
                    </div>
                    <div className="h-24 bg-blue-500/20 rounded-xl p-3">
                      <div className="text-blue-400 text-xs mb-2">المشتريات</div>
                      <div className="text-white font-bold text-lg">89,210</div>
                      <div className="text-blue-400 text-xs">+8%</div>
                    </div>
                    <div className="h-24 bg-purple-500/20 rounded-xl p-3">
                      <div className="text-purple-400 text-xs mb-2">الأرباح</div>
                      <div className="text-white font-bold text-lg">36,220</div>
                      <div className="text-purple-400 text-xs">+15%</div>
                    </div>
                  </div>
                  <div className="h-32 bg-slate-800/50 rounded-xl"></div>
                </div>
              </div>

              {/* Floating Cards */}
              <div className="absolute -top-4 -right-4 bg-white rounded-2xl p-4 shadow-xl flex items-center gap-3">
                <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center">
                  <Shield className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <div className="text-slate-800 font-semibold text-sm">أمان تام</div>
                  <div className="text-slate-500 text-xs">تشفير متقدم</div>
                </div>
              </div>

              <div className="absolute -bottom-4 -left-4 bg-white rounded-2xl p-4 shadow-xl flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  <Users className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <div className="text-slate-800 font-semibold text-sm">+500 عميل</div>
                  <div className="text-slate-500 text-xs">يثقون بنا</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center pt-2">
          <div className="w-1 h-2 bg-white rounded-full"></div>
        </div>
      </div>
    </section>
  );
}