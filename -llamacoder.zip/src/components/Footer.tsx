import { Mail, Phone, MapPin } from "lucide-react";

export function Footer() {
  return (
    <footer id="contact" className="bg-slate-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Company Info */}
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center">
                <span className="text-white font-bold text-lg">MS</span>
              </div>
              <div>
                <h3 className="font-bold text-lg">Multi System</h3>
                <p className="text-slate-400 text-sm">للحلول البرمجية</p>
              </div>
            </div>
            <p className="text-slate-400 leading-relaxed mb-6">
              نقدم حلولاً برمجية متكاملة لإدارة الأعمال بكفاءة واحترافية. نسعى لتحقيق رؤيتكم.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 bg-slate-800 rounded-full flex items-center justify-center hover:bg-emerald-500 transition-colors">
                <span className="text-sm">ت</span>
              </a>
              <a href="#" className="w-10 h-10 bg-slate-800 rounded-full flex items-center justify-center hover:bg-emerald-500 transition-colors">
                <span className="text-sm">ف</span>
              </a>
              <a href="#" className="w-10 h-10 bg-slate-800 rounded-full flex items-center justify-center hover:bg-emerald-500 transition-colors">
                <span className="text-sm">ت</span>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold text-lg mb-6">روابط سريعة</h4>
            <ul className="space-y-3">
              {["الرئيسية", "المميزات", "الباقات", "آراء العملاء", "تواصل معنا"].map((link) => (
                <li key={link}>
                  <a href="#" className="text-slate-400 hover:text-emerald-400 transition-colors">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-bold text-lg mb-6">خدماتنا</h4>
            <ul className="space-y-3">
              {["النظام المحاسبي", "إدارة المخزون", "نقاط البيع", "التقارير المالية", "الدعم الفني"].map((service) => (
                <li key={service}>
                  <a href="#" className="text-slate-400 hover:text-emerald-400 transition-colors">
                    {service}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-bold text-lg mb-6">تواصل معنا</h4>
            <ul className="space-y-4">
              <li className="flex items-center gap-3">
                <div className="w-10 h-10 bg-slate-800 rounded-lg flex items-center justify-center">
                  <Phone className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <div className="text-slate-400 text-sm">اتصل بنا</div>
                  <div className="font-medium" dir="ltr">+20 109 090 3959</div>
                </div>
              </li>
              <li className="flex items-center gap-3">
                <div className="w-10 h-10 bg-slate-800 rounded-lg flex items-center justify-center">
                  <Mail className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <div className="text-slate-400 text-sm">البريد الإلكتروني</div>
                  <div className="font-medium">info@multisystem.com</div>
                </div>
              </li>
              <li className="flex items-center gap-3">
                <div className="w-10 h-10 bg-slate-800 rounded-lg flex items-center justify-center">
                  <MapPin className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <div className="text-slate-400 text-sm">العنوان</div>
                  <div className="font-medium">القاهرة، مصر</div>
                </div>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-slate-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-slate-400 text-sm">
              © 2024 Multi System للحلول البرمجية. جميع الحقوق محفوظة.
            </p>
            <div className="flex gap-6">
              <a href="#" className="text-slate-400 hover:text-emerald-400 text-sm transition-colors">
                سياسة الخصوصية
              </a>
              <a href="#" className="text-slate-400 hover:text-emerald-400 text-sm transition-colors">
                الشروط والأحكام
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}